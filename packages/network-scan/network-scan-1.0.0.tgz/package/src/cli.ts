#!/usr/bin/env node
import { scanNetwork, PRESETS, PortPreset, ScanResult } from "./scan.js";

// Parse CLI arguments
const args = process.argv.slice(2);
const target = args.find(arg => !arg.startsWith("--")) ?? "";
const timeoutMs = Number(args.find(arg => arg.startsWith("--timeout="))?.split("=")[1]) || 2000;
const presetArg = args.find(arg => arg.startsWith("--preset="))?.split("=")[1] as PortPreset;
const concurrency = Number(args.find(arg => arg.startsWith("--concurrency="))?.split("=")[1]) || 10;
const checkVulns = args.includes("--check-vulns");
const customPorts = args.find(arg => arg.startsWith("--ports="))?.split("=")[1];
const showHelp = args.includes("--help") || !target;

function printErrorJson(message: string) {
  console.log(JSON.stringify({ success: false, error: message }, null, 2));
}

if (showHelp) {
  printErrorJson("Usage: npx network-scan <host> [options]");
  console.log(JSON.stringify({
    success: false,
    help: {
      usage: "npx network-scan <host> [options]",
      options: {
        "--preset": "TOP_100|TOP_1000|WEB|DATABASE|MAIL|ALL (default: TOP_100)",
        "--ports": "Custom port list (e.g., 80,443,8080)",
        "--timeout": "Timeout in ms (default: 2000)",
        "--concurrency": "Concurrent scans (default: 10, max: 100)",
        "--check-vulns": "Check for common vulnerabilities",
        "--help": "Show this help message"
      }
    }
  }, null, 2));
  process.exit(target ? 0 : 1);
}

const ports = customPorts
  ? customPorts.split(",").map(p => Number(p.trim()))
  : presetArg
    ? PRESETS[presetArg]
    : PRESETS.TOP_100;

scanNetwork(target, {
  ports,
  timeoutMs,
  preset: presetArg,
  concurrency,
  checkVulns,
})
  .then((result : ScanResult)=> {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch((err: Error) => {
    printErrorJson(err?.message || "Scan failed");
    process.exit(1);
  });
