import net from "net";
import dns from "dns/promises";
import { performance } from "perf_hooks";

/* =======================
   TYPES
======================= */

export type PortPreset =
  | "TOP_100"
  | "TOP_1000"
  | "WEB"
  | "DATABASE"
  | "MAIL"
  | "ALL";

export type ScanTechnique = "TCP_CONNECT";

export interface ScanResult {
  success: boolean;
  target: string;
  ip: string;
  hostname: string | null;
  scanInfo: {
    scanType: ScanTechnique;
    timeoutMs: number;
    portPreset: PortPreset | "CUSTOM";
    concurrency: number;
    startTime: string;
    endTime: string;
    durationMs: number;
    portsScanned: number;
    portsOpen: number;
  };
  osFingerprint: {
    guess: string;
    confidence: "LOW" | "MEDIUM" | "HIGH";
    indicators: string[];
  };
  ports: {
    port: number;
    state: "OPEN" | "CLOSED" | "FILTERED";
    service: string | null;
    banner: string | null;
    responseTime?: number;
  }[];
  vulnerabilities?: {
    port: number;
    service: string;
    issue: string;
    severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  }[];
  error?: string;
}

/* =======================
   PRESETS & SERVICES
======================= */

export const PRESETS: Record<PortPreset, number[]> = {
  TOP_100: [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 3306, 3389, 8080],
  TOP_1000: Array.from({ length: 1000 }, (_, i) => i + 1),
  WEB: [80, 443, 8080, 8443],
  DATABASE: [1433, 1521, 3306, 5432, 6379, 27017],
  MAIL: [25, 110, 143, 465, 587, 993, 995],
  ALL: Array.from({ length: 65535 }, (_, i) => i + 1)
};

const SERVICES: Record<number, string> = {
  21: "FTP",
  22: "SSH",
  23: "TELNET",
  25: "SMTP",
  80: "HTTP",
  443: "HTTPS",
  3306: "MYSQL",
  3389: "RDP",
  8080: "HTTP-PROXY"
};

/* =======================
   CORE SCAN LOGIC
======================= */

async function scanPort(
  host: string,
  port: number,
  timeoutMs: number
): Promise<ScanResult["ports"][0]> {
  return new Promise(resolve => {
    const socket = new net.Socket();
    const start = performance.now();
    socket.setTimeout(timeoutMs);

    socket.connect(port, host, () => {
      socket.write("\r\n");
    });

    socket.on("data", data => {
      socket.destroy();
      resolve({
        port,
        state: "OPEN",
        service: SERVICES[port] ?? null,
        banner: data.toString().split("\n")[0]?.trim() ?? null,
        responseTime: Math.round(performance.now() - start)
      });
    });

    socket.on("timeout", () => {
      socket.destroy();
      resolve({
        port,
        state: "FILTERED",
        service: SERVICES[port] ?? null,
        banner: null
      });
    });

    socket.on("error", () => {
      resolve({
        port,
        state: "CLOSED",
        service: null,
        banner: null
      });
    });
  });
}

async function scanPorts(
  host: string,
  ports: number[],
  timeoutMs: number,
  concurrency: number
) {
  const results: ScanResult["ports"] = [];
  const queue = [...ports];

  async function worker() {
    while (queue.length) {
      const port = queue.shift();
      if (!port) return;
      const res = await scanPort(host, port, timeoutMs);
      if (res.state !== "CLOSED") results.push(res);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  return results.sort((a, b) => a.port - b.port);
}

/* =======================
   PUBLIC API
======================= */

export async function scanNetwork(
  target: string,
  options?: {
    ports?: number[];
    preset?: PortPreset;
    timeoutMs?: number;
    concurrency?: number;
    checkVulns?: boolean;
  }
): Promise<ScanResult> {
  const start = Date.now();
  const timeoutMs = options?.timeoutMs ?? 2000;
  const concurrency = Math.min(options?.concurrency ?? 10, 100);

  let ip = target;
  try {
    const res = await dns.lookup(target);
    ip = res.address;
  } catch {}

  const ports =
    options?.ports ??
    (options?.preset ? PRESETS[options.preset] : PRESETS.TOP_100);

  const results = await scanPorts(ip, ports, timeoutMs, concurrency);

  return {
    success: true,
    target,
    ip,
    hostname: null,
    scanInfo: {
      scanType: "TCP_CONNECT",
      timeoutMs,
      portPreset: options?.ports ? "CUSTOM" : options?.preset ?? "TOP_100",
      concurrency,
      startTime: new Date(start).toISOString(),
      endTime: new Date().toISOString(),
      durationMs: Date.now() - start,
      portsScanned: ports.length,
      portsOpen: results.filter(p => p.state === "OPEN").length
    },
    osFingerprint: {
      guess: results.some(p => p.port === 3389) ? "Windows" : "Linux/Unix",
      confidence: "LOW",
      indicators: []
    },
    ports: results
  };
}
